package scenes

class Process {
    companion object{
        fun sum(num1 : Int, num2 : Int) : Int {
            return num1 + num2
        }
    }
}